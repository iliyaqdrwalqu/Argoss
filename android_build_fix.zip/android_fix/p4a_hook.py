"""
python-for-android build hook — ARGOS v1.4.1
=============================================
Закрывает все 5 пунктов PR «Android build fix»:

1. grp, _lzma, _uuid  — исключены из Python-сборки (нет в Android NDK).
2. long → int          — заменено в jnius_utils.pxi (Python 3 / Cython 3).
3. IF → if             — deprecated Cython IF заменён на Python if в jnius.pyx.
4. jnius.c             — генерируется через cythonize() до сборки если отсутствует.
5. Прочие расширения   — все проблемные модули отключены через disabled_modules.
"""

from __future__ import annotations

import glob
import os
import re
import subprocess
import sys

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _patch_long_to_int(path: str) -> None:
    """Заменяет isinstance(x, long) → isinstance(x, int) в файле."""
    with open(path, "r", encoding="utf-8") as fh:
        src = fh.read()

    # long как тип в isinstance
    patched = re.sub(r"\bisinstance\(([^,]+),\s*long\)", r"isinstance(\1, int)", src)
    # long как standalone аннотация/объявление типа
    patched = re.sub(r"\blong\b(?!\s*=)", "int", patched)

    if patched == src:
        return
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(patched)
    print(f"[p4a_hook] ✅ Patched 'long' -> 'int' in: {path}")


def _patch_cython_if_statements(path: str) -> None:
    """
    Заменяет устаревший Cython IF/ELIF/ELSE на Python if/elif/else.

    Cython 3.x выдаёт DeprecationWarning/Error на:
        IF UNAME_SYSNAME == "Windows":
    Правильная замена:
        import sys
        if sys.platform == "win32":
    """
    with open(path, "r", encoding="utf-8") as fh:
        src = fh.read()

    original = src

    # IF UNAME_SYSNAME == "Windows" → if sys.platform == "win32"
    src = re.sub(
        r'\bIF\s+UNAME_SYSNAME\s*==\s*["\']Windows["\']',
        'if sys.platform == "win32"',
        src,
    )
    # IF UNAME_SYSNAME == "Linux" → if sys.platform == "linux"
    src = re.sub(
        r'\bIF\s+UNAME_SYSNAME\s*==\s*["\']Linux["\']',
        'if sys.platform == "linux"',
        src,
    )
    # IF UNAME_SYSNAME == "Darwin" → if sys.platform == "darwin"
    src = re.sub(
        r'\bIF\s+UNAME_SYSNAME\s*==\s*["\']Darwin["\']',
        'if sys.platform == "darwin"',
        src,
    )
    # Общий IF … → if …  (для прочих условий)
    src = re.sub(r'\bIF\b(?=\s+\w)', 'if', src)
    # ELIF → elif
    src = re.sub(r'\bELIF\b', 'elif', src)
    # ELSE: → else:  (только в Cython-IF контексте — строки с ELSE без условия)
    src = re.sub(r'^\s*ELSE\s*:', lambda m: m.group(0).replace("ELSE", "else"), src,
                 flags=re.MULTILINE)

    # Добавить import sys если появились sys.platform и его ещё нет
    if "sys.platform" in src and "import sys" not in src:
        src = "import sys\n" + src

    if src == original:
        return
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(src)
    print(f"[p4a_hook] ✅ Patched Cython IF statements in: {path}")


def _ensure_jnius_c(pyx_path: str) -> None:
    """
    Генерирует jnius.c из jnius.pyx если файл отсутствует или устарел.
    Пункт 4 PR: «Ensure Cython generates jnius.c from jnius.pyx before build».
    """
    c_path = pyx_path.replace(".pyx", ".c")
    if os.path.exists(c_path):
        pyx_mtime = os.path.getmtime(pyx_path)
        c_mtime   = os.path.getmtime(c_path)
        if c_mtime >= pyx_mtime:
            print(f"[p4a_hook] jnius.c актуален, cythonize пропущен.")
            return

    print(f"[p4a_hook] Генерирую {c_path} из {pyx_path} ...")
    try:
        # Попытка 1: через Python API
        from Cython.Build import cythonize  # type: ignore[import]
        cythonize(pyx_path, language_level=3, force=True)
        print(f"[p4a_hook] ✅ jnius.c сгенерирован (Cython API).")
    except Exception as exc:
        print(f"[p4a_hook] Cython API недоступен ({exc}), пробую subprocess...")
        try:
            result = subprocess.run(
                [sys.executable, "-m", "cython", "--3str", pyx_path],
                capture_output=True, text=True, timeout=120,
            )
            if result.returncode == 0:
                print(f"[p4a_hook] ✅ jnius.c сгенерирован (cython CLI).")
            else:
                print(f"[p4a_hook] ⚠ cython CLI ошибка:\n{result.stderr[:500]}")
        except Exception as exc2:
            print(f"[p4a_hook] ⚠ Не удалось запустить cython: {exc2}")


# ---------------------------------------------------------------------------
# p4a hook entry-points
# ---------------------------------------------------------------------------

def before_build(toolchain) -> None:
    """Вызывается p4a до сборки любого рецепта."""
    _fix_pyjnius(toolchain)
    _disable_android_incompatible_modules(toolchain)


# ---------------------------------------------------------------------------
# Patch implementations
# ---------------------------------------------------------------------------

def _fix_pyjnius(toolchain) -> None:
    """
    Патчит pyjnius для совместимости с Python 3 / Cython 3:
    - long → int в jnius_utils.pxi       (пункт 2 PR)
    - IF → if в jnius.pyx                (пункт 3 PR)
    - генерирует jnius.c если нужно      (пункт 4 PR)
    """
    storage = getattr(toolchain, "storage_dir", None) or ""
    search_roots = [
        storage,
        os.path.expanduser("~/.buildozer"),
        os.getcwd(),
    ]

    for root in search_roots:
        if not root:
            continue

        # Пункт 2: long → int в jnius_utils.pxi
        for match in glob.glob(
            os.path.join(root, "**", "jnius_utils.pxi"), recursive=True
        ):
            _patch_long_to_int(match)

        # Пункт 2 дополнительно: long в самом jnius.pyx
        for match in glob.glob(
            os.path.join(root, "**", "jnius.pyx"), recursive=True
        ):
            _patch_long_to_int(match)
            # Пункт 3: deprecated IF → if
            _patch_cython_if_statements(match)
            # Пункт 4: генерация jnius.c
            _ensure_jnius_c(match)

        # Пункт 2: long в других .pxi файлах pyjnius
        for match in glob.glob(
            os.path.join(root, "**", "jnius*.pxi"), recursive=True
        ):
            _patch_long_to_int(match)
            _patch_cython_if_statements(match)


def _disable_android_incompatible_modules(toolchain) -> None:
    """
    Исключает Python stdlib C-расширения недоступные в Android NDK:
      * grp   — POSIX group functions (setgrent/getgrent/endgrent)
      * _uuid — требует libuuid (нет в NDK)
      * _lzma — требует liblzma/lzma.h (нет в NDK)
    Пункт 1 и 5 PR.
    """
    incompatible = {"grp", "_uuid", "_lzma"}

    # Метод 1: через Python3Recipe.disabled_modules (p4a ≥ 2022)
    try:
        from pythonforandroid.recipes.python3 import Python3Recipe  # type: ignore[import]

        existing     = set(getattr(Python3Recipe, "disabled_modules", []))
        new_disabled = sorted(existing | incompatible)
        Python3Recipe.disabled_modules = new_disabled

        added = incompatible - existing
        if added:
            print(
                f"[p4a_hook] ✅ Disabled modules added: {', '.join(sorted(added))}"
            )
    except Exception as exc:
        print(
            f"[p4a_hook] ⚠ Python3Recipe.disabled_modules недоступен ({exc}).\n"
            f"           Пробую патч setup.py напрямую..."
        )
        # Метод 2: патч setup.py Python-for-Android через env
        _patch_setup_py_env()


def _patch_setup_py_env() -> None:
    """
    Fallback: выставляет переменные окружения которые python-for-android
    читает при сборке CPython для Android.
    """
    # Некоторые версии p4a читают PYTHON_DISABLED_MODULES
    existing = os.environ.get("PYTHON_DISABLED_MODULES", "")
    modules  = set(existing.split(",")) if existing else set()
    modules.update({"grp", "_uuid", "_lzma"})
    os.environ["PYTHON_DISABLED_MODULES"] = ",".join(sorted(m for m in modules if m))
    print(
        f"[p4a_hook] PYTHON_DISABLED_MODULES="
        f"{os.environ['PYTHON_DISABLED_MODULES']}"
    )
