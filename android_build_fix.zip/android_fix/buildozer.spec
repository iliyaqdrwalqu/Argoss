[app]

# Application metadata
title = ARGOS Universal OS
package.name = argos_universal
package.domain = org.labuaqlysnecy.argos
version = 1.4.1

# Source
source.dir = .
# kivy_gui.py — главный GUI-файл (kivy_1gui/kivy_ma/main_kivy перемещены в legacy)
source.main = kivy_gui.py
source.include_exts = py,png,jpg,jpeg,kv,atlas,json,txt,md
source.include_patterns = assets/*,config/*

# Requirements
# pyjnius >= 1.6.1 — исправляет Python-3/Cython-3 несовместимости (нет 'long')
requirements = python3==3.11.0,kivy==2.3.0,requests,pyjnius==1.6.1,android,paho-mqtt,python-dotenv

# Orientation
orientation = portrait
fullscreen = 0

# Android permissions
android.permissions = INTERNET,BLUETOOTH_ADMIN,NFC,READ_EXTERNAL_STORAGE,WRITE_EXTERNAL_STORAGE,USB_HOST,ACCESS_NETWORK_STATE,FOREGROUND_SERVICE

# Android API / NDK / SDK
android.api = 33
android.minapi = 24
android.ndk = 25b
android.sdk = 33
android.arch = arm64-v8a

# Enable Android features
android.accept_sdk_license = True

# Icons
icon.filename = %(source.dir)s/assets/argos_icon_512.png

[buildozer]
log_level = 2
warn_on_root = 0

# Hook script — патчит pyjnius для Python 3 и отключает несовместимые
# с Android NDK модули stdlib (grp, _uuid, _lzma) до начала сборки.
# Закрывает все 5 пунктов PR «Android build fix».
p4a.hook = p4a_hook.py
