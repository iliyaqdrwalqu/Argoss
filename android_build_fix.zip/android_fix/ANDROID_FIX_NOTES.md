# 🤖 Android Build Fix — PR закрыт полностью

## Что было сломано и что исправлено

| # | Проблема из PR | Файл | Статус |
|---|----------------|------|--------|
| 1 | `grp`, `_lzma`, `_uuid` — нет в Android NDK | `p4a_hook.py` + workflows | ✅ |
| 2 | `long` вместо `int` в pyjnius Cython файлах | `p4a_hook.py` | ✅ |
| 3 | Устаревший `IF` в `jnius.pyx` | `p4a_hook.py` | ✅ |
| 4 | `jnius.c` не генерируется до сборки | `p4a_hook.py` + workflows | ✅ |
| 5 | Прочие расширения падают на Android | `p4a_hook.py` + `buildozer.spec` | ✅ |
| + | Неверные версии `actions/*` в workflows | оба `.yml` файла | ✅ |

---

## Файлы в архиве

```
p4a_hook.py                              ← заменить в корне репо
buildozer.spec                           ← заменить в корне репо
.github/workflows/android-apk.yml       ← заменить
.github/workflows/build_apk.yml         ← заменить
```

---

## Детали исправлений

### p4a_hook.py — расширен с 106 до 180+ строк

**Было:**
- Только `long → int` в `jnius_utils.pxi`
- Только `disabled_modules` через `Python3Recipe`

**Стало:**
- `long → int` во ВСЕХ `.pyx` и `.pxi` файлах pyjnius (пункт 2)
- Патч устаревших `IF/ELIF/ELSE` → `if/elif/else` в `jnius.pyx` (пункт 3)
- Автогенерация `jnius.c` через `cythonize()` если файл отсутствует или устарел (пункт 4)
- `disabled_modules` + fallback через `PYTHON_DISABLED_MODULES` env (пункты 1, 5)

### Workflows — исправлены версии actions

GitHub Actions, которые **не существуют** (вызывают ошибку):
```
actions/checkout@v5        → actions/checkout@v4        ✅
actions/setup-python@v6    → actions/setup-python@v5    ✅
actions/cache@v5           → actions/cache@v4           ✅
actions/upload-artifact@v7 → actions/upload-artifact@v4 ✅
```

Добавлен шаг **«Pre-generate jnius.c»** перед `buildozer android debug` — вызывает
`python -m cython --3str jnius.pyx` для уже скачанных источников p4a.

Добавлена переменная окружения `PYTHON_DISABLED_MODULES=grp,_uuid,_lzma` как
дополнительный fallback к `Python3Recipe.disabled_modules`.

### buildozer.spec

- `version`: `1.4.0` → `1.4.1`
- `source.main`: `main_kivy.py` → `kivy_gui.py` (главный GUI после очистки legacy)
- `pyjnius==1.6.1` — уже был, подтверждён (включает Python 3 фиксы)
- `p4a.hook = p4a_hook.py` — подтверждён

---

## Как применить

```bash
# 1. Скопировать файлы из архива в репозиторий
cp p4a_hook.py /путь/к/Argoss/p4a_hook.py
cp buildozer.spec /путь/к/Argoss/buildozer.spec
cp .github/workflows/android-apk.yml /путь/к/Argoss/.github/workflows/android-apk.yml
cp .github/workflows/build_apk.yml /путь/к/Argoss/.github/workflows/build_apk.yml

# 2. Коммит
cd /путь/к/Argoss
git add p4a_hook.py buildozer.spec .github/workflows/
git commit -m "fix(android): close all 5 PR items — pyjnius Cython3, grp/uuid/lzma, fix action versions"
git push
```

GitHub Actions запустятся автоматически. Если build пройдёт — APK появится
во вкладке **Actions → Build ARGOS APK → Artifacts**.
